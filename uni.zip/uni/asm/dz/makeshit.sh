nasm -felf32 task1.asm
nasm -felf32 task2.asm
nasm -felf32 task3.asm
nasm -felf32 task4.asm
nasm -felf32 task5.asm
ld -m elf_i386 task1.o -o task1
ld -m elf_i386 task2.o -o task2
ld -m elf_i386 task3.o -o task3
ld -m elf_i386 task4.o -o task4
ld -m elf_i386 task5.o -o task5

