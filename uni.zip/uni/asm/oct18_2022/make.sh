nasm -felf32 oct18_2022.asm -o link.o
ld -m elf_i386 link.o -o exec
./exec

