nasm -felf32 rmdir.asm
ld -m elf_i386 rmdir.o -o rmdir

