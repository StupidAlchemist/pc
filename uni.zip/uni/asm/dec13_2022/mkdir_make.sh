nasm -felf32 mkdir.asm
ld -m elf_i386 mkdir.o -o mkdir

