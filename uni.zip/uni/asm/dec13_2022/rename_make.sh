nasm -felf32 rename.asm
ld -m elf_i386 rename.o -o rename

