#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	for(int i = 1; i <= 20; i++){
		cout << i * i << endl;
	}
	return 0;
}

