#include <iostream>
using namespace std;
int main()
{
	unsigned int x, y, gcd;
	cin >> x >> y;
	for(unsigned int i = 1; (i <= x) && (i <= y); i++){
		if((x % i == 0) && (y % i == 0)){
			gcd = i;
		}
	}
	cout << gcd << endl;
	return 0;
}

