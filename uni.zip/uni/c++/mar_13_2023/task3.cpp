#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main(int argc, char** argv)
{
	int array[20], temp;
	srand(time(0));
	for(int& i: array){
		i = rand() % 10000 - 5000;
	}
	for(int i = 0; i < 20; i++){
		for(int j = 0; j < 19; j++){
			if(array[j + 1] < array[j]){
				temp = array[j];
				array[j] = array[j + 1];
				array[j + 1] = temp;
			}
		}
	}
	for(int& i: array){
		cout << i << endl;
	}
	return 0;
}

