#include <iostream>
using namespace std;
int main(int argc, char** argv)
{
	unsigned int num1, num2, temp;
	cout << "Enter 2 unsigned numbers: ";
	cin >> num1 >> num2;
	if(num2 > num1){
		temp = num1;
		num1 = num2;
		num2 = temp;
	}
	while(num1 % num2 != 0){
		temp = num1;
		num1 = num2;
		num2 = temp % num2;
	}
	cout << "GCD is " << num2 << endl;
	return 0;
}

