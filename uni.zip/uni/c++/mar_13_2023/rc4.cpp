#include <iostream>
#include <string.h>
#include <cstdio>
using namespace std;

int main(int argc, char** argv)
{
	if(argc != 3){
		cout << "Usage: ./exec <inputfile> <outputfile>" << endl;
		return 1;
	}
	if(!strcmp(argv[1], argv[2])){
		cout << "Files must be different" << endl;
		return 3;
	}
	FILE* input = fopen(argv[1], "rb");
	FILE* output = fopen(argv[2], "wb");
	if(input == 0){
		cout << "Error opening file " << argv[1];
		return 2;
	}
	if(output == 0){
		cout << "Error opening file " << argv[2];
		return 2;
	}
	unsigned int i, j, temp;
	unsigned char s[256];
	unsigned char k[100];
	unsigned char c;
	for(i = 0; i < 256; i++){
		s[i] = i;
	}
	for(i = 0, j = 0; i < 100;){
		i = (i + 1) % 256;
		j = (j + s[i]) % 256;
		temp = s[i];
		s[i] = s[j];
		s[j] = temp;
		k[i] = s[ (s[i] + s[j]) % 256 ];
		/*cout << (int)k[i] << endl;*/
	}
	i = 0;
	while(!feof(input)){
		if(1 != fread(&c, 1, 1, input)){
			break;
		}
		c ^= k[i];
		fwrite(&c, 1, 1, output);
		i = (i + 1) % 100;
	}
	fclose(input);
	fclose(output);
	return 0;
}

