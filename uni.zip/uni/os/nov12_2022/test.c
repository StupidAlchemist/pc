#include <stdio.h>
#include <unistd.h>
#include <wait.h>

int main(int argc, char* argv[], char* env[])
{
	pid_t pid;
	fprintf(stderr, "Zapusk\n");

	if( (-1) == (pid = fork()) ){
		perror("fork");
		return -1;
	}

	if( 0 == pid ){
		char *prog = argv[0];
		argv[0] = "myprog"
		execve(prog, &argv[0], env);
		perror("execve");
	}
	wait(NULL);
	fprintf(stderr, "Konets\n");
	return 0;
}

