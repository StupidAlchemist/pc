#include <stdio.h>
#include <unistd.h>
#include <wait.h>

int main(int argc, char* argv[], char* env[])
{
	pid_t pid;
	// fprintf(stderr, "zapusk\n");
	if( (-1) == (pid = fork()) ){
		perror("fork");
		return -1;
	}

	if( 0 == pid ){
		argv++;
		char* prog = argv[0];
		argv[0] = "task1";
		argv[1] = "task2";
		execve(prog, argv, argv);
		perror("execve");
		return -1;
	}

	wait(NULL);
	// fprintf(stderr, "konets\n");
	return 0;
}

