#include <stdio.h>
#include <string.h>
int main(void)
{
	char input[128];
	fgets(input, 128, stdin);
	if( 0 == strcmp(input, "pancakes\n") ){
		memset(input, 0, 128);
		strcpy(input, "pancakes!!!!!");
	}else{
		memset(input, 0, 128);
		strcpy(input, "not pancakes :(");
	}
	puts(input);
	return 0;
}

