#include <stdio.h>
int main(void)
{
	char input[128];
	fgets(input, 128, stdin);
	puts(input);
	return 0;
}

