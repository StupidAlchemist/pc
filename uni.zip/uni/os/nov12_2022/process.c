#include <stdio.h>
#include <unistd.h>

int global_var;
int default_value = 228;

int main(int argc, char* argv[])
{
	pid_t pid;
	int ret_code;
	char *err_msg = "fork";
	char children[10] = "I'm child";
#ifdef PARENT_MUST_DIE
	*(int*)0 = global_var;
#endif
	global_var = default_value;
	switch(pid = fork()){
	case -1:
		perror(err_msg);
		break;
	case 0:
		puts(children);
		global_var++;
		printf("In child global var = %d\n", global_var);
		return global_var;
		break;
	default:
		wait(&ret_code);
		if(WIFEXITED(ret_code)){

		printf("Child for process \'%s\' return %d\n", argv[0], WEXITSTATUS(ret_code));
		}else{
			printf("Child is killed (%d)\n", WTERMSIG(ret_code));
		}
		printf("Child for process \'%s\' return %d\n", argv[0], ret_code);
		printf("Global var = %d\n", global_var);
	}

	return 0;
}

