#include <pthread.h>
#include <stdio.h>

int global_var;
void func(void* none)
{
	global_var++;
#ifdef CHILD_MUST_DIE
	*((int*)0) = global_var;
#endif
	printf("In child global var = %d\n", global_var);
	return NULL;
}

int main(int argc, char* argv[])
{
	pthread_t pid;
	void* retval;
#ifdef PARENT_MUST_DIE
	*((int*)0) = global_var;
#endif
	pthread_create(&pid, NULL, func, NULL);
	pthread_join(pid, &retval);
	printf("Global var = %d\n", global_var);
	return 0;
}

