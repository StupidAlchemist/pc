#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int w = 1;

void func(int none)
{
	/* w = 0; */
	printf("I\'m your signal!!!\n");
}

int main(int argc, char* argv[])
{
	signal(SIGINT, func);
	signal(SIGTERM, func);
	while(1){
		printf("tik\n");
		sleep(1);
	}

	printf("Konets\n");

	return 0;
}

