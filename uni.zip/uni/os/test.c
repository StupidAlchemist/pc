#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>

int main(int argc, char* argv[])
{
	int fd;			// Ukozatel na fail
	uint16_t sector_size;	// Razmer sectora
	uint8_t claster_size;
	uint16_t count_RS;
	uint8_t count_fat;
	uint16_t fat_size;
	uint16_t first_fat_table;
	uint16_t root_directory;
	uint16_t data;
	if(argc != 2){
		fprintf(stderr, "USE: %s <floppy.img>\n", argv[0]);
		return -1;
	}
	fd = open(argv[1], O_RDONLY);
	if ((-1) == fd){
		perror("Open file");
		return -2;
	}

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	lseek(fd, 0xB, SEEK_SET);
	read(fd, &sector_size, 2);
	printf("Sector size: 0x%04X (%d)\n", sector_size, sector_size);

	first_fat_table = count_RS * sector_size;
	printf(

	close(fd);
	return 0;
}

