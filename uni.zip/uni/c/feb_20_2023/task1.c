#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char* argv[])
{
	srand(time(0));

	double arr[10][10];

	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 10; j++){
			arr[i][j] = rand() % 100000 / 10000.0;
			printf("%.4f ", arr[i][j]);
		}
		putchar('\n');
	}

	return 0;
}

