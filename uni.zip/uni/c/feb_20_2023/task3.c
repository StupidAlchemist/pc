#include <stdio.h>

void f1(int a)
{
	a += 10;
}

void f2(int *a)
{
	*a *= 2;
}

int main(int argc, char* argv[])
{
	int a = 42;
	printf("%d\n", a);
	f1(a);
	printf("%d\n", a);
	f2(&a);
	printf("%d\n", a);
	return 0;
}

