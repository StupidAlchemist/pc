#include <stdio.h>

int main(int argc, char* argv[])
{
	int x;
	scanf("%d", &x);
	if(x){
		printf("Not zero\n");
	}else{
		printf("Zero\n");
	}
	return 0;
}

