#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char* argv[])
{
	srand(time(0));

	unsigned arr1[10];
	unsigned arr2[10];

	for(int i = 0; i < 10; i++){
		arr1[i] = rand() / 32768;
		arr2[i] = rand() / 32768;
		printf("%u\n", arr1[i] * arr2[i]);
	}

	return 0;
}

