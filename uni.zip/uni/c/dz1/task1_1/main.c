#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char* argv[])
{
	srand(time(0));

	double arr1[15];
	double arr2[15];

	for(int i = 0; i < 15; i++){
		arr1[i] = rand() / 32768.0;
		arr2[i] = rand() / 32768.0;
		printf("%.6f\n", arr1[i] - arr2[i]);
	}

	return 0;
}

