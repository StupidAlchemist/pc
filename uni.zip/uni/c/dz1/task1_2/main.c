#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char* argv[])
{
	srand(time(0));

	unsigned arr1[20];
	unsigned arr2[20];

	for(int i = 0; i < 20; i++){
		arr1[i] = rand();
		arr2[i] = rand();
		printf("%u\n", arr1[i] + arr2[i]);
	}

	return 0;
}

