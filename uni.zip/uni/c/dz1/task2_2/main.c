#include <stdio.h>

int main(int argc, char* argv[])
{
	unsigned arr[20];
	
	arr[0] = 1;

	for(int i = 1; i < 20; i++){
		arr[i] = arr[i - 1] * 2;
	}

	return 0;
}

