#include <stdio.h>

int main(int argc, char* argv[])
{
	int i = 0;
	int pos = 0;
	char str1[] = "This is a ";
	char str2[] = "combination of two strings";
	char str3[128] = {0};

	while(str1[i] != '\0'){
		str3[i] = str1[i];
		i++;
	}

	pos = i;
	i = 0;
	while(str2[i] != '\0'){
		str3[pos + i] = str2[i];
		i++;
	}

	printf("%s\n", str3);

	return 0;
}

