#include <stdio.h>

int main(int argc, char* argv[])
{
	double arr[15];

	arr[0] = 0.5;

	for(int i = 1; i < 15; i++){
		arr[i] = arr[i - 1] / 2;
	}

	return 0;
}

