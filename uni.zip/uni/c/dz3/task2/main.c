#include <stdio.h>

union myunion
{
	unsigned int  uint;
	unsigned char arr[4];
};

void func(union myunion* ob)
{
	unsigned char temp = ob->arr[0];
	ob->arr[0] = ob->arr[3];
	ob->arr[3] = temp;
	temp = ob->arr[3];
	ob->arr[3] = ob->arr[2];
	ob->arr[2] = temp;
}

int main(int argc, char** argv)
{
	union myunion ob;
	printf("Enter unsigned number: ");
	scanf("%u", &ob.uint);
	printf("uint = %u (%#010x)\n", ob.uint, ob.uint);
	func(&ob);
	printf("func(&ob)\n");
	printf("uint = %u (%#010x)\n", ob.uint, ob.uint);

	return 0;
}

