#include <stdio.h>
#include <math.h>

typedef struct
{
	double x, y;
} point;

double calculate_distance(const point* ob1, const point* ob2)
{
	double dist_x, dist_y;
	dist_x = ob1->x - ob2->x;
	dist_y = ob1->y - ob2->y;
	return sqrt(dist_x * dist_x + dist_y * dist_y);
}

int main(int argc, char** argv)
{
	double dist;
	point ob1, ob2;

	printf("Enter x and y coordinates for ob1: ");
	scanf("%lf%lf", &ob1.x, &ob1.y);

	printf("Enter x and y coordinates for ob2: ");
	scanf("%lf%lf", &ob2.x, &ob2.y);

	dist = calculate_distance((const point*)&ob1, (const point*)&ob2);
	printf("Distance between (%.6f, %.6f) and (%.6f, %.6f) is %.6f\n",
		       	ob1.x, ob1.y, ob2.x, ob2.y, dist);
	return 0;
}

