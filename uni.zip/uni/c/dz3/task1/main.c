#include <stdio.h>

int main(int argc, char** argv)
{
	FILE *inputfile;
	int total = 0;
	int chars[256] = {0};
	int i = 0;
	unsigned char c;

	if(argc != 2){
		printf("Usage: ./exec <filename>\n");
		return 1;
	}

	inputfile = fopen(argv[1], "r");
	if(inputfile == 0){
		printf("Cannot open file \'%s\'\n", argv[1]);
		return 2;
	}
	
	while(!feof(inputfile)){
		fscanf(inputfile, "%c", &c);
		chars[c]++;
		total++;
	}

	while(i < 256){
		if(chars[i] != 0){
			printf("%c (%#x) : %d\n", i, i, chars[i]);
		}
		i++;
	}
	printf("Total characters: %d\n", total);
	return 0;
}

