#include <stdio.h>

enum days
{
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
};

int main(int argc, char** argv)
{
	int x;
	scanf("%d", &x);
	switch(x){
	case MONDAY:
		printf("It's monday\n");
		break;
	case TUESDAY:
		printf("It's tuesday\n");
		break;
	case WEDNESDAY:
		printf("It's wednesday\n");
		break;
	case THURSDAY:
		printf("It's thursday\n");
		break;
	case FRIDAY:
		printf("It's friday\n");
		break;
	case SATURDAY:
		printf("It's saturday\n");
		break;
	case SUNDAY:
		printf("It's sunday\n");
		break;
	default:
		printf("Incorrect value\n");
	}
	return 0;
}

