#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct student
{
	unsigned id;
	unsigned age;
	float avg;
	int course;
	char name[32];
};

void get_default(struct student *ob, const char** names)
{
	static int count = 1;
	strcpy(ob->name, names[rand() % 10]);
	ob->id = count;
	ob->age = 18 + rand() % 6;
	ob->avg = 2.0 + 3.0 * rand() / RAND_MAX;
	ob->course = 1 + rand() % 5;
	count++;
}

void print_struct(const struct student* ob)
{
	printf("%-10s %3u %d %.2f %d\n", ob->name, ob->id, ob->age, ob->avg, ob->course);
}

void set_names(char** array)
{
	strcpy(array[0], "Alexander");
	strcpy(array[1], "Vasilii");
	strcpy(array[2], "Sergei");
	strcpy(array[3], "Evgenii");
	strcpy(array[4], "Nikita");
	strcpy(array[5], "Alexandra");
	strcpy(array[6], "Masha");
	strcpy(array[7], "Natalia");
	strcpy(array[8], "Ksenia");
	strcpy(array[9], "Anastasia");
}

int main(int argc, char** argv)
{
	srand(time(0));
	int i = 0;
	char* names[10];
	struct student students[100];
	while(i < 10){
		names[i] = malloc(32);
		i++;
	}
	set_names(names);
	i = 0;
	while(i < 100){
		get_default(&students[i], (const char**)names);
		print_struct(&students[i]);
		i++;
	}

	i = 0;
	while(i < 10){
		free(names[i]);	
		i++;
	}
	return 0;
}

