#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void set_array(int* array, unsigned count)
{
	int i = 0;
	while(i < count){
		array[i] = rand();
		i++;
	}
}

void print_array(const int* array, unsigned count)
{
	int i = 0;
	while(i < count){
		printf("ptr[%d] = %d\n", i, array[i]);
		i++;
	}
}

int main(int argc, char** argv)
{
	srand(time(0));
	unsigned count;
	int *ptr;
	scanf("%u", &count);
	ptr = (int*)malloc(sizeof(int) * count);
	set_array(ptr, count);
	print_array((const int*)ptr, count);
	printf("\nAdding 2 elements\n\n");
	ptr = realloc(ptr, (count + 2) * sizeof(int));
	ptr[count] = 0;
	ptr[count + 1] = 1;
	print_array((const int*)ptr, count + 2);
	free(ptr);

	return 0;
}

