#include <stdio.h>
#include <stdlib.h>
#include <time.h>

union example
{
	unsigned int f_32;
	unsigned short f_16;
	unsigned char f_8;
};

void set_example(union example* ob)
{
	ob->f_32 = rand();
	ob->f_16 = rand();
	ob->f_8 = rand();
}

void print_example(const union example* ob)
{
	int i = 0;
	unsigned p = 1 << 31;
	printf("f_32 = %u\n", ob->f_32);
	printf("f_16 = %hu\n", ob->f_16);
	printf("f_8 = %u\n", ob->f_8);
	while(i < 32){
		printf("%u", (ob->f_32 & p) / p);
		p >>= 1;
		i++;
	}
	printf("\n");
}

int main(int argc, char** argv)
{
	srand(time(0));
	union example array[5];
	int i = 0;
	while(i < 5){
		set_example(array);
		print_example((const union example*)array);
		i++;
	}
	return 0;
}

