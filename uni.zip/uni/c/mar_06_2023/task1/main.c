#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct student
{
	long id;
	unsigned age;
	char name[32];
	float avg;
	int course;
};

void get_default(struct student *ob)
{
	static int count = 1;
	strcpy(ob->name, "student");
	ob->id = count;
	ob->age = 18 + rand() % 6;
	ob->avg = 2.0 + 3.0 * rand() / RAND_MAX;
	ob->course = 1 + rand() % 5;
	count++;
}

void print_struct(const struct student* ob)
{
	printf("%s %3u %d %.2f %d\n", ob->name, ob->id, ob->age, ob->avg, ob->course);
}

int main(int argc, char** argv)
{
	srand(time(0));
	struct student st;
	int i = 0;
	/*strcpy(st.name, "Yuriy");
	st.age = 19;
	st.avg = 4.6;
	st.course = 2;*/
	while(i < 10){
		get_default(&st);
		print_struct(&st);
		i++;
	}
	return 0;
}

