#include <stdio.h>

void make_normal_string(char* str)
{
	int i = 1;
	if(*str != '\0'){
		if(str[0] >= 'a' && str[0] <= 'z'){
			str[0] -= 32;
		}
		while(str[i] != '\0'){
			if(str[i] >= 'A' && str[i] <= 'Z'){
				str[i] += 32;
			}
			i++;
		}
	}
}

int main(int argc, char** argv)
{
	char str[256] = {0};
	fgets(str, 256, stdin);
	make_normal_string(str);
	printf("%s", str);
	return 0;
}

