#include <stdio.h>

void my_upper(char* str)
{
	int i = 0;
	while(str[i] != '\0'){
		if(str[i] >= 'a' && str[i] <= 'z'){
			str[i] -= 32;
		}
		i++;
	}
}

int main(int argc, char** argv)
{
	char str[256] = {0};
	fgets(str, 256, stdin);
	my_upper(str);
	printf("%s", str);
	return 0;
}

