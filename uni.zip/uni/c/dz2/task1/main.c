#include <stdio.h>

int main(int argc, char* argv[])
{
	char array[12];
	char c;
	int i = 0;
	while(1){
		scanf("%c", &c);
		if(c >= 'A' && c <= 'Z'){
			array[i] = c;
			i++;
		}
		if(i == 12){
			break;
		}
	}
	printf("%12s\n", array);
	return 0;
}

