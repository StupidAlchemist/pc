#include <stdio.h>

void func(int* a, int* b)
{
	*a = *a * *b;
}

int main(int argc, char** argv)
{
	int x, y;
	printf("Enter x and y: ");
	scanf("%d%d", &x, &y);
	func(&x, &y);
	printf("x = %d, y = %d\n", x, y);
	return 0;
}

