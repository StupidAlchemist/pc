#include <stdio.h>
#include <math.h>
int main(int argc, char* argv[])
{
	unsigned int prime;
	FILE *output_file;
	output_file = fopen("./prime_numbers.txt", "w");
	if(0 == output_file){
		fprintf(stderr, "Error opening file\n");
		return 1;
	}
	for(unsigned int i = 2; i < 65538; i++){
		prime = 1;
		for(unsigned int j = 2; j < 258; j++){
			if(j >= i) break;
			if(i % j == 0){
				prime = 0;
				break;
			}
		}
		if(prime){
			fprintf(output_file, "%u\n", i);
		}
	}
	fclose(output_file);
	return 0;
}

