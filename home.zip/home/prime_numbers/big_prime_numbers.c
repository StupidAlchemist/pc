#include <stdio.h>
#include <stdlib.h>
int main(int argc, char* argv[])
{
	FILE *input_file, *output_file;
	unsigned int prime, array_count = 0;
	unsigned int *prime_array;
	input_file = fopen("./prime_numbers.txt", "r");
	output_file = fopen("./big_prime_numbers.txt", "w");
	if(0 == output_file || 0 == input_file){
		fprintf(stderr, "Error opening file\n");
		return 1;
	}
	prime_array = 0;
	while(EOF != fscanf(input_file, "%u", &prime)){
		array_count++;
		prime_array = realloc(prime_array, array_count * sizeof(unsigned));
		prime_array[array_count - 1] = prime;
	}
	for(unsigned int i = 2; i != 0; i++){
		prime = 1;
		for(unsigned j = 0; j < array_count; j++){
			if(i % prime_array[j] == 0){
				prime = 0;
				break;
			}
		}
		if(prime){
			fprintf(output_file, "%u\n", i);
		}
	}
	fclose(input_file);
	fclose(output_file);
	free(prime_array);
	return 0;
}

