#include "../headers/cost.h"

unsigned cost(const struct weapon_data* ob)
{
	unsigned c = 0;
	c += ob->weapon->damage_upgrade_cost * \
	     ob->damage_upgrade_level;
	c += ob->weapon->firing_speed_upgrade_cost * \
	     ob->firing_speed_upgrade_level;
	c += ob->weapon->reload_speed_upgrade_cost * \
	     ob->reload_speed_upgrade_level;
	c += ob->weapon->clip_size_upgrade_cost * \
	     ob->clip_size_upgrade_level;
	return c;
}

