#include "../headers/sort_cost.h"

int sort_cost(const void* a, const void* b)
{
	const struct weapon_data* ob1;
	const struct weapon_data* ob2;

	ob1 = (const struct weapon_data*)a;
	ob2 = (const struct weapon_data*)b;
	
	if(ob1->upgrade_cost > ob2->upgrade_cost){
		return 1;
	}else if(ob1->upgrade_cost < ob2->upgrade_cost){
		return -1;
	}else{
		if(ob1->ramp_up_dps > ob2->ramp_up_dps){
			return 1;
		}else if(ob2->ramp_up_dps < ob2->ramp_up_dps){
			return -1;
		}else{
			return 0;
		}
	}
}

