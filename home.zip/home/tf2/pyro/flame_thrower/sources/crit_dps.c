#include "../headers/base_dps.h"
#include "../headers/crit_dps.h"

double crit_dps(const struct weapon_data* ob)
{
	return 3 * base_dps(ob);
}

