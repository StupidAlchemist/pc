#include "../headers/tf2_weapons.h"
#include "../headers/base_dps.h"
#include "../headers/ramp_up_dps.h"
#include "../headers/mini_crit_dps.h"
#include "../headers/crit_dps.h"
#include "../headers/cost.h"
#include "../headers/sort_dps.h"
#include "../headers/sort_cost.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char* argv[])
{
	FILE* output;
	struct weapon_data *array;
	unsigned array_size, t;
	struct tf2_weapon_stats ob;
	int(*sort_func)(const void*, const void*);

	if(argc != 3){
		printf("Usage: ./exec -d / -c output.txt\n");
		return 1;
	}

	if(0 == strcmp(argv[1], "-d")){
		sort_func = sort_dps;
	}else if(0 == strcmp(argv[1], "-c")){
		sort_func = sort_cost;
	}else{
		printf("Incorrect flag %s\n", argv[1]);
		return 2;
	}

	output = fopen(argv[2], "w");
	if(0 == output){
		printf("Error opening file %s\n", argv[2]);
		return 3;
	}

	ob.reloads_clip_at_once = 0;
	ob.base_damage = 13;
	ob.damage_increase = 0;
	ob.damage_ramp_up = 0;
	ob.damage_upgrade_step = 0.25;
	ob.damage_upgrade_count = 4;
	ob.damage_upgrade_cost = 400;
	ob.base_clip_size = 0;
	ob.clip_size_increase = 0;
	ob.clip_size_upgrade_step = 0;
	ob.clip_size_upgrade_count = 0;
	ob.clip_size_upgrade_cost = 400;
	ob.base_firing_speed = 0.075;
	ob.firing_speed_increase = 0;
	ob.firing_speed_upgrade_step = 0.1;
	ob.firing_speed_upgrade_count = 0;
	ob.firing_speed_upgrade_cost = 200;
	ob.reload_speed_first = 0;
	ob.base_reload_speed = 0;
	ob.reload_speed_increase = 0;
	ob.reload_speed_upgrade_count = 0;
	ob.reload_speed_upgrade_step = 0.2;
	ob.reload_speed_upgrade_cost = 250;


	array_size = (1 + ob.damage_upgrade_count) * \
		     (1 + ob.firing_speed_upgrade_count) * \
		     (1 + ob.reload_speed_upgrade_count) * \
		     (1 + ob.clip_size_upgrade_count);

	array = malloc(sizeof(struct weapon_data) * array_size);

	for(unsigned i = 0; i < array_size; i++){
		t = i;
		array[i].weapon = &ob;
		array[i].damage_upgrade_level = \
			t % (1 + ob.damage_upgrade_count);
		t /= (1 + ob.damage_upgrade_count);
		array[i].clip_size_upgrade_level = \
			t % (1 + ob.clip_size_upgrade_count);
		t /= (1 + ob.clip_size_upgrade_count);
		array[i].firing_speed_upgrade_level = \
			t % (1 + ob.firing_speed_upgrade_count);
		t /= (1 + ob.firing_speed_upgrade_count);
		array[i].reload_speed_upgrade_level = t;

		array[i].base_dps 	= base_dps(&array[i]);
		array[i].ramp_up_dps 	= ramp_up_dps(&array[i]);
		array[i].mini_crit_dps 	= mini_crit_dps(&array[i]);
		array[i].crit_dps	= crit_dps(&array[i]);
		array[i].upgrade_cost 	= cost(&array[i]);
	}
	
	qsort(array, array_size, sizeof(struct weapon_data), sort_func);
	fprintf(output, "D C F R COST   base_dps  ramp_up_dps "\
			" mini_crit_dps  crit_dps \n"); 
	for(int i = 0; i < array_size; i++){
		fprintf(output, "%1d %1d %1d %1d %4d %11.6f %11.6f "\
				"%13.6f %11.6f\n", \
			array[i].damage_upgrade_level,\
			array[i].clip_size_upgrade_level,\
			array[i].firing_speed_upgrade_level,\
			array[i].reload_speed_upgrade_level,\
			array[i].upgrade_cost,\
			array[i].base_dps,\
			array[i].ramp_up_dps,\
			array[i].mini_crit_dps,\
			array[i].crit_dps);

	}

	free(array);

	return 0;
}

