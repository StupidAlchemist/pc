#include "../headers/ramp_up_dps.h"
#include "../headers/mini_crit_dps.h"

double mini_crit_dps(const struct weapon_data* ob)
{
	return 1.35 * ramp_up_dps(ob);
}

