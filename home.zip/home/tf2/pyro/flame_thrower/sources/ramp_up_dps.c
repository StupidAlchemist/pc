#include "../headers/base_dps.h"
#include "../headers/ramp_up_dps.h"

double ramp_up_dps(const struct weapon_data* ob)
{
	return base_dps(ob) * (1 + ob->weapon->damage_ramp_up);
}

