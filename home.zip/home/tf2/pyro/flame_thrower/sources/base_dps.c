#include "../headers/base_dps.h"

double base_dps(const struct weapon_data *ob)
{
	double dps_per_clip;
	double time_per_clip;

	double damage;
	double firing_speed;
	double reload_speed;
	unsigned clip_size;

	damage = ob->weapon->base_damage;
	damage += ob->weapon->damage_increase;
	damage += ob->weapon->base_damage * \
		  ob->weapon->damage_upgrade_step * ob->damage_upgrade_level;

	firing_speed = ob->weapon->base_firing_speed;
	firing_speed -= ob->weapon->firing_speed_increase;
	firing_speed -= ob->weapon->base_firing_speed * \
		ob->weapon->firing_speed_upgrade_step * \
		ob->firing_speed_upgrade_level;
	if(firing_speed < 0){
		firing_speed = 0;
	}
	reload_speed = ob->weapon->base_reload_speed;
	reload_speed -= ob->weapon->reload_speed_increase;
	reload_speed -= ob->weapon->base_reload_speed * \
		ob->weapon->reload_speed_upgrade_step * \
		ob->reload_speed_upgrade_level;

	clip_size = ob->weapon->base_clip_size;
	clip_size += ob->weapon->clip_size_increase;
	clip_size += ob->weapon->clip_size_upgrade_step * \
		     ob->clip_size_upgrade_level;

	if(clip_size == 0){
		dps_per_clip = damage;
		time_per_clip = firing_speed;
	}else{
		dps_per_clip = damage * clip_size;
		time_per_clip = firing_speed * clip_size;
		if(ob->weapon->reloads_clip_at_once){
			time_per_clip += reload_speed;
		}else{
			time_per_clip += reload_speed * (clip_size - 1);
			time_per_clip += ob->weapon->reload_speed_first * \
				(1 - ob->weapon->reload_speed_upgrade_step * ob->reload_speed_upgrade_level);
		}
	}
	return dps_per_clip / time_per_clip;
}

