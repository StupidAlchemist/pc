#ifndef MY_CRIT_DPS
#define MY_CRIT_DPS

#include "./tf2_weapons.h"

double crit_dps(const struct weapon_data*);

#endif

