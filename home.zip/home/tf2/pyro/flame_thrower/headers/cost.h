#ifndef MY_COST
#define MY_COST

#include "./tf2_weapons.h"

unsigned cost(const struct weapon_data*);

#endif
