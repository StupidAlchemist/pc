#ifndef MY_TF2_WEAPON_STATS
#define MY_TF2_WEAPON_STATS

struct tf2_weapon_stats
{
	double base_damage;
	double reload_speed_increase;
	double firing_speed_increase;
	double damage_increase;
	double damage_upgrade_step;
	double damage_ramp_up;
	double base_reload_speed;
	double reload_speed_upgrade_step;
	double base_firing_speed;
	double firing_speed_upgrade_step;
	double clip_size_upgrade_step;
	double reload_speed_first;
	double reload_speed_first_step;
	unsigned base_clip_size;
	unsigned damage_upgrade_count;
	unsigned reload_speed_upgrade_count;
	unsigned firing_speed_upgrade_count;
	unsigned clip_size_upgrade_count;
	unsigned damage_upgrade_cost;
	unsigned reload_speed_upgrade_cost;
	unsigned firing_speed_upgrade_cost;
	unsigned clip_size_upgrade_cost;
	unsigned reloads_clip_at_once;
	unsigned clip_size_increase;
};

struct weapon_data
{
	const struct tf2_weapon_stats* weapon;
	double base_dps;
	double ramp_up_dps;
	double mini_crit_dps;
	double crit_dps;
	unsigned upgrade_cost;
	unsigned damage_upgrade_level;
	unsigned reload_speed_upgrade_level;
	unsigned firing_speed_upgrade_level;
	unsigned clip_size_upgrade_level;
};

#endif

