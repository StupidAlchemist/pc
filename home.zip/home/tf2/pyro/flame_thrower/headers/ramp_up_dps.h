#ifndef MY_RAMP_UP_DPS
#define MY_RAMP_UP_DPS

#include "./tf2_weapons.h"

double ramp_up_dps(const struct weapon_data*);

#endif

