#ifndef MY_SORT_COST
#define MY_SORT_COST

#include "./tf2_weapons.h"

int sort_cost(const void*, const void*);

#endif

