#ifndef MY_BASE_DPS
#define MY_BASE_DPS

#include "./tf2_weapons.h"

double base_dps(const struct weapon_data*);

#endif

