#ifndef MY_SORT_DPS
#define MY_SORT_DPS

#include "./tf2_weapons.h"

int sort_dps(const void*, const void*);

#endif
