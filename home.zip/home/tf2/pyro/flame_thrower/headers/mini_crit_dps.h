#ifndef MY_MINI_CRIT_DPS
#define MY_MINI_CRIT_DPS

#include "./tf2_weapons.h"

double mini_crit_dps(const struct weapon_data*);

#endif

