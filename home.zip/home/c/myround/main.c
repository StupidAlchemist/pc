#include <stdio.h>

float myround(float value)
{
	int bitvalue;
	int mantissa;
	int exponent;
	int temp;
	int sign;

	bitvalue = *((unsigned*)&value);
	temp = bitvalue;
	sign = (bitvalue < 0 ? -1 : 1);
	mantissa = (temp & ((1 << 23) - 1));
	exponent = ((temp >> 23) & 255);
	exponent -= 127;
	temp = 22 - exponent;
	if((mantissa & (1 << (temp)))){
		mantissa ^= ((1 << temp) - 1);
	}else{
		mantissa ^= ((1 << (temp - 1)) - 1);
	}
	bitvalue = mantissa + ((exponent + 127) << 23);
	value = sign * *((float*)&bitvalue);
	return value;
}

int main(int argc, char** argv)
{
	float f;

	scanf("%f", &f);

	printf("myround(%f) = %.0f\n", f, myround(f));

	return 0;
}

