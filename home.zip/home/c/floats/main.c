#include <stdio.h>

union float_bytes
{
	float value;
	unsigned int uvalue;
	unsigned char bytes[sizeof(float)];
};

float delta_float(const union float_bytes* ob)
{
	union float_bytes temp;
	temp.uvalue = ob->uvalue + 1;
	return temp.value - ob->value;

}

int main(int argc, char** argv)
{
	union float_bytes ob;
	scanf("%f", &ob.value);
	printf("%.50f\n", delta_float((const union float_bytes*)&ob));
	return 0;
}

