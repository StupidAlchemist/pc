#include <stdio.h>

void set_bits(unsigned number, char* bit_array)
{
	int i = 0;
	unsigned char c;
	while(i < 32){
		c = *((unsigned char*)&number + i / 8);
		bit_array[31 - i] = '0' + ((c >> i % 8) & 1);
		i++;
	}
	bit_array[32] = 0;
}

int main(int argc, char** argv)
{
	unsigned number, mask;
	char unsigned_bits[33] = {0};
	scanf("%u%u", &number, &mask);
	/* printf("%#010x & %#010x = %#010x\n", number, mask, number & mask);
	printf("%#010x | %#010x = %#010x\n", number, mask, number | mask);
	printf("%#010x ^ %#010x = %#010x\n", number, mask, number ^ mask);
	printf("~number = %#010x\n", ~number);
	printf("~mask = %#010x\n", ~mask); */
	number ^= mask;
	set_bits(number, unsigned_bits);
	printf("%s\n", unsigned_bits);
	return 0;
}

