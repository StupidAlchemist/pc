#include <stdio.h>

#ifdef __cplusplus
#error This code is not compatable with c++
#endif

int main(int argc, char** argv)
{
	
	return 0;
}

